const skills = [
  { name: 'UI Design', note: 'Clean, readable, diegetic UI', level: 3 },
  { name: 'Building', note: 'Layout, dressing, lighting passes', level: 3 },
  { name: 'Composer', note: '30–60s loops, stings, hits', level: 4 },
  { name: 'Game Design', note: 'Mechanics, balance, encounter flow', level: 4 },
  { name: 'Storytelling', note: 'Lore shards, world tone, NPC voice', level: 5 }
]

export default function Skills() {
  return (
    <section id="skills" className="section">
      <h2 className="text-3xl font-heading font-semibold">Skills</h2>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {skills.map(s => (
          <div key={s.name} className="glass rounded-xl p-5">
            <h3 className="text-lg font-semibold">{s.name}</h3>
            <p className="text-gray-300 mt-1">{s.note}</p>
            <div className="mt-3 h-2 bg-white/10 rounded">
              <div className="h-full rounded bg-brand-cyan" style={{ width: `${(s.level/5)*100}%` }} />
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}