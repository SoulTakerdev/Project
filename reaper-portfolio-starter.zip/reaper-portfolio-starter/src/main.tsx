import { StrictMode, useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

function RootApp() {
  useEffect(() => {
    const loader = document.getElementById('loader')
    if (loader) loader.style.display = 'none'
    const rootEl = document.getElementById('root')
    if (rootEl) rootEl.style.opacity = '1'
  }, [])
  return <App />
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RootApp />
  </StrictMode>
)