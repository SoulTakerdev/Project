import Navbar from './Navbar'
import Hero from './Hero'
import Projects from './Projects'
import Skills from './Skills'
import About from './About'
import Contact from './Contact'
import Footer from './Footer'

export default function App() {
  return (
    <>
      <Navbar />
      <main className="pt-20 space-y-24">
        <Hero />
        <Projects />
        <Skills />
        <About />
        <Contact />
      </main>
      <Footer />
    </>
  )
}