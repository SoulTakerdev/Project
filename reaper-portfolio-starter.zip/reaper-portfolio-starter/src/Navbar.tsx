const links = [
  { href: '#projects', label: 'Projects' },
  { href: '#skills', label: 'Skills' },
  { href: '#about', label: 'About' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar() {
  return (
    <nav className="fixed top-0 inset-x-0 z-50 bg-black/70 backdrop-blur-md border-b border-white/10">
      <div className="section flex items-center justify-between h-16">
        <a href="#hero" className="text-xl font-heading font-bold tracking-widest">REAPER</a>
        <ul className="hidden sm:flex gap-6 text-sm text-gray-300">
          {links.map(l => (
            <li key={l.href}><a className="hover:text-white" href={l.href}>{l.label}</a></li>
          ))}
        </ul>
        <a href="#contact" className="btn hidden sm:inline-flex">Contact</a>
      </div>
    </nav>
  )
}