import { useState } from 'react'

type Tag = 'UI' | 'Building' | 'Music' | 'Design' | 'Story'
type Filter = 'All' | Tag

type Project = {
  title: string
  description: string
  tags: Tag[]
  thumbnail?: string
  link?: string
}

const projects: Project[] = [
  {
    title: 'Cyber Ruins',
    description: 'Neon arena prototype. I handled UI, level dressing, and music loop.',
    tags: ['UI','Building','Music','Design'],
    link: '#'
  },
  {
    title: 'EchoBound Tests',
    description: 'Small encounter spaces with adaptive music and lore terminals.',
    tags: ['Design','Story','Building']
  },
  {
    title: 'Warden’s Trial',
    description: 'Boss room iteration; diegetic UI and sting-based score.',
    tags: ['Music','UI','Design']
  }
]

const filters: Filter[] = ['All','UI','Building','Music','Design','Story']

function ProjectCard({ p }: { p: Project }) {
  return (
    <article className="glass rounded-xl overflow-hidden">
      <div className="aspect-video bg-gradient-to-br from-zinc-800 to-zinc-900 flex items-center justify-center">
        {p.thumbnail ? (
          <img src={p.thumbnail} alt={p.title} className="w-full h-full object-cover" />
        ) : (
          <span className="text-gray-400">No thumbnail yet</span>
        )}
      </div>
      <div className="p-5 text-left">
        <h3 className="text-xl font-semibold">{p.title}</h3>
        <p className="mt-2 text-gray-300">{p.description}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {p.tags.map(t => (
            <span key={t} className="text-xs px-2 py-1 rounded bg-white/5 border border-white/10">{t}</span>
          ))}
        </div>
        {p.link && (
          <a className="mt-4 inline-block link" href={p.link} target="_blank" rel="noopener noreferrer">Open project ↗</a>
        )}
      </div>
    </article>
  )
}

export default function Projects() {
  const [active, setActive] = useState<Filter>('All')
  const visible = projects.filter(p => active === 'All' || p.tags.includes(active))

  return (
    <section id="projects" className="section">
      <h2 className="text-3xl font-heading font-semibold">Projects</h2>
      <p className="mt-2 text-gray-300">Filter by role to see relevant work.</p>

      <div className="mt-6 flex flex-wrap gap-2">
        {filters.map(f => (
          <button
            key={f}
            onClick={() => setActive(f)}
            className={`px-3 py-1 rounded border ${active===f ? 'border-brand-cyan text-brand-cyan' : 'border-white/15 text-gray-300 hover:text-white'} transition`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {visible.map(p => <ProjectCard key={p.title} p={p} />)}
      </div>
    </section>
  )
}