export default function Contact() {
  return (
    <section id="contact" className="section">
      <h2 className="text-3xl font-heading font-semibold">Contact</h2>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <form
          name="contact"
          method="POST"
          data-netlify="true"
          netlify-honeypot="bot-field"
          className="glass rounded-xl p-6 space-y-4"
        >
          <input type="hidden" name="form-name" value="contact" />
          <p className="hidden"><label>Don’t fill this out: <input name="bot-field" /></label></p>
          <input className="w-full bg-white/5 border border-white/10 rounded p-3" name="name" placeholder="Your name" required />
          <input className="w-full bg-white/5 border border-white/10 rounded p-3" name="email" placeholder="Your email" type="email" required />
          <textarea className="w-full bg-white/5 border border-white/10 rounded p-3" name="message" rows={5} placeholder="Message" required />
          <button className="btn w-full" type="submit">Send</button>
        </form>

        <div className="glass rounded-xl p-6">
          <h3 className="font-semibold">Links</h3>
          <ul className="mt-3 space-y-2">
            <li><a className="link" href="https://www.roblox.com/users/profile" target="_blank" rel="noopener noreferrer">Roblox Profile</a></li>
            <li><a className="link" href="https://github.com/" target="_blank" rel="noopener noreferrer">GitHub</a></li>
            <li><a className="link" href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer">YouTube</a></li>
            <li><a className="link" href="https://soundcloud.com/" target="_blank" rel="noopener noreferrer">Sound</a></li>
            <li><a className="link" href="https://discord.gg/" target="_blank" rel="noopener noreferrer">Discord</a></li>
          </ul>
          <p className="mt-4 text-gray-400 text-sm">Email: <span className="text-white">deathbound.reaper@gmail.com</span></p>
        </div>
      </div>
    </section>
  )
}