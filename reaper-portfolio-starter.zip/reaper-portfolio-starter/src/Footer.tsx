import { useState } from 'react'

export default function Footer() {
  const [open, setOpen] = useState(false)
  return (
    <footer className="mt-24 border-t border-white/10">
      <div className="section py-8 text-sm text-gray-400 flex items-center justify-between">
        <p>© {new Date().getFullYear()} Reaper. Forged on Netlify.</p>
        <button className="text-gray-500 hover:text-white" onClick={() => setOpen(v => !v)} title="Lore" aria-label="Lore">☠️</button>
      </div>
      {open && (
        <div className="section pb-10">
          <div className="glass p-6 rounded-xl text-gray-200">
            <p className="text-sm"><span className="font-heading tracking-wider text-white">Marrow’s Note:</span> Beneath the hub, the engines hum. Lantern’s Ash, Echoes Endure.</p>
          </div>
        </div>
      )}
    </footer>
  )
}