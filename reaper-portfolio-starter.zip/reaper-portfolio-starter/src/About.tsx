export default function About() {
  return (
    <section id="about" className="section">
      <h2 className="text-3xl font-heading font-semibold">About</h2>
      <div className="mt-6 grid md:grid-cols-2 gap-6 items-start">
        <div className="glass rounded-xl p-6">
          <p className="text-gray-200">
            I’m Reaper. Intermediate at UI and Building, Composer, Game Designer,
            and a storyteller who ships. I like clean interfaces, readable feedback,
            and levels that teach by doing.
          </p>
          <ul className="mt-4 list-disc list-inside text-gray-300">
            <li>Tooling: Roblox Studio, VS Code, Git, Figma/BandLab</li>
            <li>Music: short loops, stingers, impact hits</li>
            <li>Dev Style: small iterations, strong polish passes</li>
          </ul>
        </div>
        <div className="glass rounded-xl p-6">
          <h3 className="font-semibold">Process</h3>
          <ol className="mt-3 space-y-2 text-gray-300">
            <li><span className="text-white">1) Concept</span> — goal, verbs, mood</li>
            <li><span className="text-white">2) Build</span> — blockout, temp UI/audio</li>
            <li><span className="text-white">3) Polish</span> — readability, timing, juice</li>
            <li><span className="text-white">4) Launch</span> — test, iterate, ship</li>
          </ol>
        </div>
      </div>
    </section>
  )
}