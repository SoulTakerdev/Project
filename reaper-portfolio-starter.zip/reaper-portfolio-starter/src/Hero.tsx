export default function Hero() {
  return (
    <section id="hero" className="relative min-h-[80vh] flex items-center">
      <div className="section text-center">
        <h1 className="text-4xl sm:text-6xl font-heading font-bold leading-tight">
          I build worlds, score their sound, and tell their stories.
        </h1>
        <p className="mt-4 text-gray-300 max-w-2xl mx-auto">
          Roblox Game Designer • Intermediate UI & Builder • Composer • Storyteller
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <a className="btn" href="#projects">See My Work</a>
          <a className="px-5 py-3 rounded-lg border border-white/20 hover:border-white/40 transition" href="#about">About Me</a>
        </div>
      </div>
      <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-black/0 via-black/20 to-black" />
    </section>
  )
}